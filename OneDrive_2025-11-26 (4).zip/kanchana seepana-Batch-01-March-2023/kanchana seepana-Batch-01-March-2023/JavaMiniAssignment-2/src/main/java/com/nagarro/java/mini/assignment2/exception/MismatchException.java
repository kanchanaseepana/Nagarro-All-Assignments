package com.nagarro.java.mini.assignment2.exception;

public class MismatchException extends RuntimeException {

    public MismatchException(String message) {
        super(message);
    }
}
