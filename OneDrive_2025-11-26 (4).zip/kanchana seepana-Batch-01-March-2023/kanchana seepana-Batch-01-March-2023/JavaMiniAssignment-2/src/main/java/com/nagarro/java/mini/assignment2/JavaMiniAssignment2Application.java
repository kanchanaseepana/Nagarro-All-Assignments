package com.nagarro.java.mini.assignment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaMiniAssignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaMiniAssignment2Application.class, args);
	}

}
