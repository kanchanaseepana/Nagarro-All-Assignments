package com.nagarro.java.mini.assignment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaMiniAssignment2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
