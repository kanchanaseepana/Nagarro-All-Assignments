
import { Link } from 'react-router-dom';

const PostsExcerpt = ({ post }) => {
    return (
        <article>
            
                <Link to={`post/${post.id}` } className='link'>
                    <h2>{post.title}</h2>
                    {/* <img src={post.image} alt={post.title} /> */}
                
                </Link>

            
        </article>
    )
}
export default PostsExcerpt