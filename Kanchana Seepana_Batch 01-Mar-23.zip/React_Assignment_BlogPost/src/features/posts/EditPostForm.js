import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { selectPostById, updatePost} from './postsSlice'
import { useParams, useNavigate } from 'react-router-dom'

//import { selectAllUsers } from "../users/usersSlice";

const EditPostForm = () => {
    const { postId } = useParams()
    const navigate = useNavigate()

    const post = useSelector((state) => selectPostById(state, Number(postId)))
    //const users = useSelector(selectAllUsers)

    const [title, setTitle] = useState(post?.title)
    const [Categories, setCategories] = useState(post?.Categories)
    const [content, setContent] = useState(post?.body)
    const [image, setImage] = useState(post?.image)
    //const [userId, setUserId] = useState(post?.userId)
    const [requestStatus, setRequestStatus] = useState('idle')
    const [errors, setErrors] = useState({});

    const dispatch = useDispatch()

    if (!post) {
        return (
            <section>
                <h2>Post not found!</h2>
            </section>
        )
    }

    const onTitleChanged = e => setTitle(e.target.value)
    const onCategoriesChanged = e => setCategories(e.target.value)
    const onContentChanged = e => setContent(e.target.value)
    const onImageChanged = e => setImage(e.target.value)
    //const onAuthorChanged = e => setUserId(Number(e.target.value))


   // const canSave = [title,Categories, content].every(Boolean) && requestStatus === 'idle';

   const validateTitle = (title) => {
    if (!title) {
      return "Title is required.";
    }
    if (title.length < 5) {
      return "Title must be at least 3 characters long.";
    }
    if (!/^[a-zA-Z0-9_ -]*[a-zA-Z0-9][a-zA-Z0-9_ -]*$/.test(title)) {
        return "Title should contain only alphabets and numbers.";
    }
    return null;
  };
  
  const validateCategories = (categories) => {
    if (!categories) {
      return "Categories are required.";
    }
    if (categories.length < 3) {
      return "Categories must be at least 3 characters long.";
    }
    if (!/^[a-zA-Z0-9_ -]*[a-zA-Z0-9][a-zA-Z0-9_ -]*$/.test(title)) {
        return "Categories should contain only alphabets and numbers.";
    }
    return null;
  };


  const canSave = [title,Categories,image, content].every(Boolean) && requestStatus === 'idle';



    const onSavePostClicked = () => {
        const titleError = validateTitle(title);
        const categoriesError = validateCategories(Categories);
        //const contentError = validateTitle(content);
        if (!titleError && !categoriesError) {
            try {
                setRequestStatus('pending')
                dispatch(updatePost({ id: post.id, title,Categories,image, body: content, reactions: post.reactions })).unwrap()

                setTitle('')
                setCategories('')
                setContent('')
                setImage('')
                //setUserId('')
                navigate(`/post/${postId}`)
            } catch (err) {
                console.error('Failed to save the post', err)
            } finally {
                setRequestStatus('idle')
            }
        }
        else {
            setErrors({
              title: titleError,
              Categories: categoriesError,
            });
          }
    }

    /*const usersOptions = users.map(user => (
        <option
            key={user.id}
            value={user.id}
        >{user.name}</option>
    ))*/

    

    return (
        <section>
            <h2>Edit Post</h2>
            <form>
                <label htmlFor="postTitle">Post Title:</label>
                <input
                    type="text"
                    id="postTitle"
                    name="postTitle"
                    value={title}
                    onChange={onTitleChanged}
                />
                 {errors.title && <p className="error">{errors.title}</p>}
                <label htmlFor="postCategories">Categories:</label>
                <input
                    type="text"
                    id="postCategories"
                    name="postCategories"
                    value={Categories}
                    onChange={onCategoriesChanged}
                />
                 {errors.Categories && <p className="error">{errors.Categories}</p>}
                
                <label htmlFor="postContent">Content:</label>
                <textarea
                    id="postContent"
                    name="postContent"
                    value={content}
                    onChange={onContentChanged}
                />
                 {/* {errors.content && <p className="error">{errors.content}</p>} */}
                 

<label htmlFor="postImage">Image:</label>

                <input

                    type="text"

                    id="postImage"

                    name="postImage"

                    value={image}

                    onChange={onImageChanged}

                />
                <button
                    type="button"
                    onClick={onSavePostClicked}
                    disabled={!canSave}
                >
                    Save Post
                </button>
                
            </form>
        </section>
    )
}

export default EditPostForm