import { useState } from "react";
import { useDispatch} from "react-redux";

import { addNewPost } from "./postsSlice";
//import { selectAllUsers } from "../users/usersSlice";
import { useNavigate } from "react-router-dom";

const AddPostForm = () => {
    const dispatch = useDispatch()

    const navigate = useNavigate()

    const [title, setTitle] = useState('')
    const [content, setContent] = useState('')
    const [Categories, setCategories] = useState('')
    const [image, setImage] = useState('')
    //const [userId, setUserId] = useState('')
    const [addRequestStatus, setAddRequestStatus] = useState('idle')

    const [errors, setErrors] = useState({});

    //const users = useSelector(selectAllUsers)

    const onTitleChanged = e => setTitle(e.target.value)
    const onContentChanged = e => setContent(e.target.value)
    const onCategoriesChanged=e => setCategories(e.target.value)
    const onImageChanged = (e) => {
        const inputValue = e.target.value;
        if (isValidURL(inputValue)) {
          setImage(inputValue);
        } else {
          // Show a validation error for invalid URL
          setErrors({ ...errors, image: "Invalid image URL" });
        }
      };
    //const onAuthorChanged = e => setUserId(e.target.value)


    
    

  const validateTitle = (title) => {
    if (!title) {
      return "Title is required.";
    }
    if (title.length < 5) {
      return "Title must be at least 3 characters long.";
    }
    if (!/^[a-zA-Z0-9_ -]*[a-zA-Z0-9][a-zA-Z0-9_ -]*$/.test(title)) {
        return "Title should contain only alphabets and numbers.";
    }
    return null;
  };
  
  const validateCategories = (categories) => {
    if (!categories) {
      return "Categories are required.";
    }
    if (categories.length < 3) {
      return "Categories must be at least 3 characters long.";
    }
    if (!/^[a-zA-Z0-9_ -]*[a-zA-Z0-9][a-zA-Z0-9_ -]*$/.test(title)) {
        return "Categories should contain only alphabets and numbers.";
    }
    return null;
  };
  const isValidURL = (url) => {
    // Use a regular expression to check if the input is a valid URL
    const urlPattern = /^(http[s]?:\/\/|www\.|ftp:\/\/)(www\.)?[a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)$/i;
    return urlPattern.test(url);
  };

  // const validateContent = (content) => {
  //   if (!content) {
  //     return "Categories are required.";
  //   }
  //   if (content.length < 3) {
  //     return "Categories must be at least 3 characters long.";
  //   }
  //   if (!/^[a-zA-Z0-9]+$/.test(content)) {
  //       return "Categories should contain only alphabets and numbers.";
  //   }
  //   return null;
  // };
  const canSave = [title,Categories, content,image].every(Boolean) && addRequestStatus === 'idle';




//   const canSave =
//   !validateTitle(title) &&
//   !validateCategories(Categories) &&
//   !validateContent(content) &&
//   addRequestStatus === "idle";


 
  

    const onSavePostClicked = () => {
        const titleError = validateTitle(title);
        const categoriesError = validateCategories(Categories);
        if (!titleError && !categoriesError) {
            try {
                setAddRequestStatus('pending')
                dispatch(addNewPost({ title,Categories,image, body: content })).unwrap()

                setTitle('')
                setCategories('')
                setContent('')
                setImage('')
                navigate('/')
            } catch (err) {
                console.error('Failed to save the post', err)
            } finally {
                setAddRequestStatus('idle')
            }
            
        }
        else {
            setErrors({
              title: titleError,
              Categories: categoriesError,
            });
          }

    };

    

    /*const usersOptions = users.map(user => (
        <option key={user.id} value={user.id}>
            {user.name}
        </option>
    ))*/

    return (
        <section>
            <h2>Add a New Post</h2>
            <form>
                <label htmlFor="postTitle">Title:</label>
                <input
                    type="text"
                    id="postTitle"
                    name="postTitle"
                    value={title}
                    onChange={onTitleChanged}
                />
                 {errors.title && <p className="error">{errors.title}</p>}
                <label htmlFor="postCategories">Categories:</label>
                <input
                    type="text"
                    id="postCategories"
                    name="postCategories"
                    value={Categories}
                    onChange={onCategoriesChanged}
                />
                {errors.Categories && <p className="error">{errors.Categories}</p>}
                
                <label htmlFor="postContent">Content:</label>
                <textarea
                    id="postContent"
                    name="postContent"
                    value={content}
                    onChange={onContentChanged}
                />
                 {errors.content && <p className="error">{errors.content}</p>}
                 <label htmlFor="postImage">Image:</label>

                <input

                    type="text"

                    id="postImage"

                    name="postImage"

                    value={FormData.Image}

                    onChange={onImageChanged}

                />
                {errors.image && <p className="error">{errors.image}</p>}
                <button
                    type="button"
                    onClick={onSavePostClicked}
                    disabled={!canSave}
                >Submit</button>
            </form>
        </section>
    )
}
export default AddPostForm