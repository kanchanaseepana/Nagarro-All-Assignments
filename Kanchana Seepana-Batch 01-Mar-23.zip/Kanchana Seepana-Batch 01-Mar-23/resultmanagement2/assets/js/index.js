$("#add_user").submit(function(event){
    alert("Data is inserted successfullyyy !!!!!!!!!!");
})
$("update_user").submit(function(event){
    event.preventDefault();
    var unindexed_array = $(this).serializeArray();
    var data ={}
    $.map(unindexed_array,function(n,i){
        data[n['name']]=n['value']
    })
    console.log(data);
    var request={
        "url":`http://localhost:3000/api/students/$(data.id)`,
        "method":"PUT",
        "data":data
    }
    $.ajax(request).done(function(response){
        alert("DATA UPDATED SUCCESSSS!!!!!!!!!!")
    })
})
$("#update_user").submit(function(event){
    alert("DATA updtae sucessss");
})


if(window.location.pathname == "/index"){
    $ondelete = $(".table tbody td a.delete");
    $ondelete.click(function(){
        var id = $(this).attr("data-id")

        var request = {
            "url" : `http://localhost:3000/api/students/${id}`,
            "method" : "DELETE"
        }

        if(confirm("Do you really want to delete this record?")){
            $.ajax(request).done(function(response){
                alert("Data Deleted Successfully!");
                location.reload();
            })
        }

    })
}