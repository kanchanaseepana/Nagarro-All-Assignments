const express=require('express');
const route=express.Router()

const services= require('../services/render');
const controller=require('../controller/student');


//home route
//route.get('/homepage', services.homemethod)
route.get('/index',services.homeRoutes)


route.get('/addstudent',services.addstudent)


route.get('/updatestudent',services.updatestudent)
route.post('/logout',services.logout)




//API
route.post('/api/students', controller.create);
route.get('/api/students', controller.find);
route.put('/api/students/:id', controller.update);
route.delete('/api/students/:id', controller.delete);
route.post('/api/update/:id',controller.update);









//teacher login methods




route.get('/login',services.teacher_login_get)
route.post('/login',services.teacher_login_post)


//student login

route.get('/student/login',services.student_login_get);
route.post('/student/login', services.findstudent);



module.exports=route