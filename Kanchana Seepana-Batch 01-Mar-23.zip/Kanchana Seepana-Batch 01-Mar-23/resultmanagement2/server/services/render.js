const axios = require('axios');
const Userdb = require('../model/model');


exports.homeRoutes = (req,res)=>{
    axios.get('http://localhost:3000/api/students')
    .then(function(response){
        console.log(response.data)
    res.render('index',{students: response.data});
    })
    .catch(err=>{
        res.send(err);
    })
}




exports.addstudent=(req,res)=>{
    //const error='erroe'
    res.render('addstudent');
}

exports.updatestudent=(req,res)=>{
    axios.get('http://localhost:3000/api/students',{params:{id:req.query.id}})
    .then(function(userdata){
        res.render("updatestudent", {students:userdata.data})
    })
    //res.render('updatestudent');
    .catch(err=>{
        res.send(err);
    })
}
exports.teacher_login_get = (req, res) => {
    res.render("login");
};


exports.teacher_login_post = (req,res) => {
    if(req.body.password == "pswd"){
        req.session.name=req.body.password;
        res.redirect("index");
    }
    else{
        res.render("login", {
            error : "Please Enter Correct Password"
        })
    }
}


//student services

exports.student_login_get = (req, res) => {
    res.render("student/login");
 };

 

exports.findstudent = async(req, res) => {
  //const { roll, dob } = req.body;
  try{
   // console.log(req.body);
  rollnum=req.body.roll;
  dateofbirth=req.body.dob;
 const student=await Userdb.findOne({roll:rollnum});
 const studentdob=student.dob;
 console.log(student.dob);
 console.log(studentdob);
 if(student.roll==rollnum && student.dob===dateofbirth){
    res.status(200).render("student/view",{student});
 }else{
    res.status(200).render("404");
 }

  }
  catch(err){
      console.error(err);
      res.status(500).send({ message: "An error occurred." });
    };
};

exports.logout=(req,res)=>{
    req.session.destroy((err) => {
    
            if (err) {
    
              console.error(err);
    
            } else {
    
              res.clearCookie('connect.sid'); // Clear the session cookie
    
              res.redirect('/');
    
              return; // Redirect to a suitable page after logout
    
            }
    
          });
        }
