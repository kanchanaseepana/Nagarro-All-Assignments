const mongoose=require('mongoose');
  var schema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    roll: {

        type : Number,
    
        unique : true
    
      } ,
      dob:{

        type: String
    
      } ,
    
      score:{
        type: Number

      }
  })

  const Userdb= mongoose.model('studentdb', schema);

  module.exports = Userdb;